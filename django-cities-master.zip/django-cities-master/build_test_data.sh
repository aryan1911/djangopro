#!/bin/bash

DJANGO_SETTINGS_MODULE=test_project.test_app.settings python ./build_test_data.py $1
